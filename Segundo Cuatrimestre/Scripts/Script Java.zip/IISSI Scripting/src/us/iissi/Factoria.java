package us.iissi;

import java.util.GregorianCalendar;

public class Factoria {
	
	public static Integer[][] matriculas = { { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };

	public static String getRandomFechaNacimiento() {
		GregorianCalendar gc = new GregorianCalendar();
		int year = randBetween(1992, 2012);
		gc.set(GregorianCalendar.YEAR, year);
		int dayOfYear = randBetween(1, gc.getActualMaximum(GregorianCalendar.DAY_OF_YEAR));
		gc.set(GregorianCalendar.DAY_OF_YEAR, dayOfYear);

		String dia = String.valueOf(gc.get(GregorianCalendar.DAY_OF_MONTH));
		if (dia.length() < 2)
			dia = "0" + dia;
		String mes = String.valueOf(gc.get(GregorianCalendar.MONTH) + 1);
		if (mes.length() < 2)
			mes = "0" + mes;

		return dia + mes + gc.get(GregorianCalendar.YEAR);
	}

	public static String getRandomDireccion() {
		Integer n = randBetween(1, 10);
		Integer n2 = randBetween(1, 50);
		return "Calle Test" + n + " n�" + n2;
	}

	public static String getEmail(String nombre, String apellido1, String apellido2) {
		String res = "";
		if (nombre.length() < 3) {
			res += nombre.substring(0, 2);
		} else {
			res += nombre.substring(0, 3);
		}
		if (nombre.length() < 3) {
			res += apellido1.substring(0, 2);
		} else {
			res += apellido1.substring(0, 3);
		}
		if (nombre.length() < 3) {
			res += apellido2.substring(0, 2);
		} else {
			res += apellido2.substring(0, 3);
		}
		res = res.replace(" ", "").replace("�", "a").replace("�", "e").replace("�", "i").replace("�", "o")
				.replace("�", "u").toLowerCase();

		return res + "@testmail.com";
	}

	public static String getRandomTelefono() {
		String res = "555";
		for (int i = 0; i < 6; i++)
			res += randBetween(0, 9);
		return res;
	}

	public static String getRandomDerechos() {
		return "" + randBetween(0, 1);
	}

	public static Integer getRandomAniosVeterania(Integer edad) {
		Integer res;
		if (edad < 6) {
			res = Factoria.randBetween(1, edad - 3);
		} else {
			res = Factoria.randBetween(1, 4);
		}
		return res;
	}

	public static String getRandomFechaMatriculacion(Integer anioMatriculacion) {
		String dia = String.valueOf(Factoria.randBetween(1, 15));
		if (dia.length() < 2)
			dia = "0" + dia;
		return dia + "09" + anioMatriculacion;
	}

	public static String getCodigo(Integer anioMatriculacion, Integer curso, Boolean menor) {
		String res = "";
		if (menor)
			res += "i";
		res += curso;
		matriculas[2015 - anioMatriculacion][curso - 1]++;
		String n = "" + matriculas[2015 - anioMatriculacion][curso - 1];
		if (n.length() < 2)
			n = "0" + n;
		return res + n;
	}

	public static String getRandomDiaLaborable(Integer anioMatriculacion) {
		
		String res = "";
		while (res.isEmpty()){
			GregorianCalendar gc = new GregorianCalendar();
			int year = anioMatriculacion;
			gc.set(GregorianCalendar.YEAR, year);
	
			int dayOfYear = Factoria.randBetween(1, gc.getActualMaximum(GregorianCalendar.DAY_OF_YEAR));
			gc.set(GregorianCalendar.DAY_OF_YEAR, dayOfYear);
	
			String dia = String.valueOf(gc.get(GregorianCalendar.DAY_OF_MONTH));
			if (dia.length() < 2)
				dia = "0" + dia;
			String mes = String.valueOf(gc.get(GregorianCalendar.MONTH) + 1);
			if (mes.length() < 2)
				mes = "0" + mes;
			if ((!(mes == "07" || mes == "08" || mes == "09"))
					&& (!(gc.get(GregorianCalendar.DAY_OF_WEEK) == 6 || gc.get(GregorianCalendar.DAY_OF_WEEK) == 7))) {
				res += dia + mes + gc.get(GregorianCalendar.YEAR);
	
			}
		}
		return res;
	}

	public static int randBetween(int start, int end) {
		return start + (int) Math.round(Math.random() * (end - start));
	}
}
