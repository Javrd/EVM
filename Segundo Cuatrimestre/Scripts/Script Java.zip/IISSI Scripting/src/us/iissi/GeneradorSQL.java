package us.iissi;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import us.iissi.enums.Apellidos;
import us.iissi.enums.Nombres;

public class GeneradorSQL {

	public static String[] asignaturas = { "Viol�n", "Viola", "Violonchelo", "Saxof�n", "Flauta travesera", "Clarinete",
			"Tromb�n", "Trompeta", "Trompa", "Percusi�n", "Piano y guitarra", "Lenguaje Musical",
			"Expresion Corporal y Danza", "Pr�ctica de orquesta" };

	public static Map<String, Boolean> instrumentos = new HashMap<String, Boolean>();
	public static Integer nInstrumentos = 10;
	public static Random rand = new Random();

	public static String getRandomCargaInicial() {

		for (int i = 0; i < nInstrumentos; i++) {
			instrumentos.put("violin" + (i + 1), true);
			instrumentos.put("guitarra" + (i + 1), true);
			instrumentos.put("clarinete" + (i + 1), true);
			instrumentos.put("trompeta" + (i + 1), true);
		}

		String output = "";
		output += declaraVariables();
		output += crearAsignaturas();
		output += crearInstrumentos();
		for (int i = 0; i < 100; i++) {
			output += crearUsuario() + "\n";
		}
		output += "END;";
		return output;
	}

	private static String declaraVariables() {
		String res = "DECLARE\n";
		for (int i = 0; i < asignaturas.length; i++) {
			res += "oid_a" + (i + 1) + " asignaturas.oid_a%type;\n";
		}
		for (int i = 0; i < nInstrumentos; i++) {
			res += "oid_violin" + (i + 1) + " instrumentos.oid_i%type;\n";
			res += "oid_guitarra" + (i + 1) + " instrumentos.oid_i%type;\n";
			res += "oid_clarinete" + (i + 1) + " instrumentos.oid_i%type;\n";
			res += "oid_trompeta" + (i + 1) + " instrumentos.oid_i%type;\n";
		}
		res += "w_oid_m matriculas.oid_m%type;\n";
		res += "BEGIN\n";
		return res;
	}

	private static String crearAsignaturas() {
		String res = "";
		for (int i = 0; i < asignaturas.length; i++) {
			res += "crear_asignatura('" + asignaturas[i] + "');\n";
			res += "oid_a" + (i + 1) + " := sec_a.currval;\n";
		}
		return res;
	}

	private static String crearInstrumentos() {
		String res = "";
		for (int i = 0; i < nInstrumentos; i++) {
			res += "crear_instrumento('violin', 1, 'violin" + (i + 1) + "', '" + getRandomEstado() + "');\n";
			res += "oid_violin" + (i + 1) + " := sec_i.currval;\n";

			res += "crear_instrumento('violin', 1, 'guitarra" + (i + 1) + "', '" + getRandomEstado() + "');\n";
			res += "oid_guitarra" + (i + 1) + " := sec_i.currval;\n";

			res += "crear_instrumento('violin', 1, 'clarinete" + (i + 1) + "', '" + getRandomEstado() + "');\n";
			res += "oid_clarinete" + (i + 1) + " := sec_i.currval;\n";

			res += "crear_instrumento('violin', 1, 'trompeta" + (i + 1) + "', '" + getRandomEstado() + "');\n";
			res += "oid_trompeta" + (i + 1) + " := sec_i.currval;\n";
		}
		return res;
	}

	private static String getRandomEstado() {
		String estado = "";
		Integer n;
		n = Factoria.randBetween(1, 3);

		switch (n) {
		case 1:
			estado = "Nuevo";
			break;
		case 2:
			estado = "Usado";
			break;
		case 3:
			estado = "Deteriorado";
			break;
		}
		return estado;
	}

	private static String crearUsuario() {
		String res = "";

		String nombre = Nombres.getRandomNombre();
		String apellido1 = Apellidos.getRandomApellido();
		String apellido2 = Apellidos.getRandomApellido();
		String fechaNacimiento = Factoria.getRandomFechaNacimiento();
		Integer edad = 2016 - Integer.parseInt(fechaNacimiento.substring(4));
		String direccion = Factoria.getRandomDireccion();
		String email = Factoria.getEmail(nombre, apellido1, apellido2);
		String telefono = Factoria.getRandomTelefono();
		String derechos = Factoria.getRandomDerechos();

		res += "crear_usuario ('" + nombre + "', '" + apellido1 + " " + apellido2 + "', to_date('" + fechaNacimiento
				+ "', 'ddmmYYYY'), '" + direccion + "', '" + email + "', " + telefono + ", " + derechos + ");";

		if (edad < 18) {
			res += "\n" + creaResponsable(apellido1, telefono);
			res += "\ncrear_relacion(sec_u.currval, sec_r.currval, 'Padre');";
		}
		;

		Integer aniosVeterania = Factoria.getRandomAniosVeterania(edad);
		Integer anioMatriculacion = 2015;
		Integer[] instrumentos = { Factoria.randBetween(1, 11), Factoria.randBetween(1, 11) };
		for (int i = 0; i < aniosVeterania; i++) {
			Boolean infantil = false;
			if (edad < 7) {
				infantil = true;
			}
			res += "\n" + crearMatricula(anioMatriculacion, aniosVeterania, infantil, edad, instrumentos);
			anioMatriculacion--;
			edad++;
		}

		return res;
	}

	private static String creaResponsable(String apellido1, String telefono) {
		String nombre = Nombres.getRandomNombre();
		String apellido2 = Apellidos.getRandomApellido();
		String email = Factoria.getEmail(nombre, apellido1, apellido2);
		return "crear_responsable('" + nombre + "', '" + apellido1 + " " + apellido2 + "', '" + email + "', " + telefono
				+ ");";
	}

	private static String crearMatricula(Integer anioMatriculacion, Integer aniosVeterania, Boolean menor, Integer edad,
			Integer[] instrumentos) {
		String res = "";
		String fechaMatriculacion = Factoria.getRandomFechaMatriculacion(anioMatriculacion);
		Integer curso = anioMatriculacion - (2015 - aniosVeterania);
		String codigo = Factoria.getCodigo(anioMatriculacion, curso, menor);
		res += "crear_matricula(to_date('" + fechaMatriculacion + "', 'ddmmYYYY'), " + curso + ", '" + codigo
				+ "', sec_u.currval);";
		res += "\ncrear_pertenece_a(sec_m.currval,oid_a12);";
		res += "\ncrear_pertenece_a(sec_m.currval,oid_a14);";
		Integer instrumento1 = null, instrumento2 = null;
		if (edad < 7) {
			res += "\ncrear_pertenece_a(sec_m.currval,oid_a1);";
			res += "\ncrear_pertenece_a(sec_m.currval,oid_a13);";
			instrumento1 = 1;
		} else {
			res += "\ncrear_pertenece_a(sec_m.currval,oid_a" + instrumentos[0] + ");";
			res += "\ncrear_pertenece_a(sec_m.currval,oid_a" + instrumentos[1] + ");";
			instrumento1 = instrumentos[0];
			instrumento2 = instrumentos[1];
		}
		if (instrumento1 != null) {
			res += crearPrestamo(instrumento1, fechaMatriculacion, anioMatriculacion);
		} else if (instrumento2 != null) {
			res += crearPrestamo(instrumento2, fechaMatriculacion, anioMatriculacion);
		}

		res += "\nw_oid_m :=sec_m.currval;";
		if (anioMatriculacion != 2015) {
			res += "\nUPDATE pagos SET estado='Pagado' where oid_m=w_oid_m;";
		} else {
			String conceptos[] = { "Matricula", "Octubre", "Noviembre", "Diciembre", "Enero", "Febrero", "Marzo",
					"Abril", "Mayo", "Junio" };

			for (int i = 0; i < 9; i++) {
				res += "\nUPDATE pagos SET estado='Pagado' where " + "(oid_m=w_oid_m and concepto='" + conceptos[i]
						+ "');";
			}
		}

		Double p;
		for (int i = 0; i < 10; i++) {
			p = rand.nextDouble();
			if (p < 0.05) {
				res += crearFalta(anioMatriculacion);
			}
		}
		return res;
	}

	private static String crearPrestamo(Integer instrumento, String fechaMatriculacion, Integer anioMatriculacion) {
		String res = "";
		String strInstrumento = "";
		switch (instrumento) {
		case 1:
			strInstrumento = "violin";
			break;
		case 6:
			strInstrumento = "clarinete";
			break;
		case 8:
			strInstrumento = "trompeta";
			break;
		case 11:
			strInstrumento = "guitarra";
			break;
		}

		for (String inst : instrumentos.keySet()) {
			if (inst.startsWith(strInstrumento) && instrumentos.get(inst)) {
				res += "\ncrear_prestamo(to_date('" + fechaMatriculacion + "', 'ddmmYYYY'),sec_m.currval,oid_" + inst
						+ ");";
				if (anioMatriculacion != 2015) {
					res += "\nUPDATE instrumentos SET libre=1 WHERE oid_i=oid_" + inst + ";";
				} else {
					instrumentos.put(inst, false);
				}
				break;
			}
		}

		return res;
	}

	private static String crearFalta(Integer anioMatriculacion) {
		String res = "";
		String dia = "";
		dia += Factoria.getRandomDiaLaborable(anioMatriculacion);
		if (!dia.isEmpty()) {
			res += "\ncrear_falta('Asistencia', to_date('" + dia + "', 'ddmmYYYY'), 1, w_oid_m);";
		}
		return res;
	}

}
