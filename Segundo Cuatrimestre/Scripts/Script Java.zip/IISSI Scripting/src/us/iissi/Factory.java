package us.iissi;

import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import us.iissi.enums.Apellidos;
import us.iissi.enums.Nombres;

public class Factory {
	
	public static Integer[][] matriculas = {{0,0,0,0},{0,0,0,0},{0,0,0,0},
										{0,0,0,0}};
	public static String[] asignaturas = {"Viol�n", "Viola", "Violonchelo", 
					"Saxof�n", "Flauta travesera", "Clarinete", "Tromb�n", 
					"Trompeta", "Trompa", "Percusi�n", "Piano y guitarra", 
					"Lenguaje Musical", "Expresion Corporal y Danza", 
					"Pr�ctica de orquesta"};

	public static Map<String,Boolean> instrumentos = new HashMap<String,Boolean>();
	public static Integer nInstrumentos = 10;
	
	public static String getRandomCargaInicial(){
		
		for (int i=0; i<nInstrumentos; i++){
			instrumentos.put("violin"+(i+1),true);
			instrumentos.put("guitarra"+(i+1),true);
			instrumentos.put("clarinete"+(i+1),true);
			instrumentos.put("trompeta"+(i+1),true);
		}
		
		String output="";
		output += declaraVariables();
		output += crearAsignaturas();
		output += crearInstrumentos();
		for (int i = 0; i < 100; i++) {
			output += crearUsuario()+"\n";
		}
		output+="END;";
		return output;
	}
	private static String crearInstrumentos() {
		String res = "";
		for(int i=0; i<nInstrumentos; i++){
			res += "crear_instrumento('violin', 1, 'violin"+(i+1)+"', '"+getEstado()+"');\n";
			res += "oid_violin"+ (i+1) + " := sec_i.currval;\n";

			res += "crear_instrumento('violin', 1, 'guitarra"+(i+1)+"', '"+getEstado()+"');\n";
			res += "oid_guitarra"+ (i+1) + " := sec_i.currval;\n";

			res += "crear_instrumento('violin', 1, 'clarinete"+(i+1)+"', '"+getEstado()+"');\n";
			res += "oid_clarinete"+ (i+1) + " := sec_i.currval;\n";

			res += "crear_instrumento('violin', 1, 'trompeta"+(i+1)+"', '"+getEstado()+"');\n";
			res += "oid_trompeta"+ (i+1) + " := sec_i.currval;\n";
		}
		return res;
	}
	private static String getEstado() {
		String estado = "";
		Integer n;
		n = randBetween(1, 3);
		
		switch (n) {
		case 1:
			estado = "Nuevo";
			break;
		case 2:
			estado = "Usado";
			break;
		case 3:
			estado = "Deteriorado";
			break;
		}
		return estado;
	}
	private static String declaraVariables() {
		String res = "DECLARE\n";
		for (int i = 0; i < asignaturas.length; i++) {
			res+= "oid_a"+ (i+1) + " asignaturas.oid_a%type;\n";
		}
		for (int i = 0; i < nInstrumentos; i++) {
			res+= "oid_violin"+ (i+1) + " instrumentos.oid_i%type;\n";
			res+= "oid_guitarra"+ (i+1) + " instrumentos.oid_i%type;\n";
			res+= "oid_clarinete"+ (i+1) + " instrumentos.oid_i%type;\n";
			res+= "oid_trompeta"+ (i+1) + " instrumentos.oid_i%type;\n";
		}
		res += "BEGIN\n";
		return res;
	}
	private static String crearAsignaturas() {
		String res = "";
		for (int i = 0; i < asignaturas.length; i++) {
			res += "crear_asignatura('"+asignaturas[i]+"');\n";
			res += "oid_a"+ (i+1) + " := sec_a.currval;\n";
		}
		return res;
	}
	private static String crearUsuario() {
		String res = "";
		
		String nombre = Nombres.getRandomNombre();
		String apellido1 = Apellidos.getRandomApellido();
		String apellido2 = Apellidos.getRandomApellido();
		String fechaNacimiento = getRandomFechaNacimiento();
		Integer edad = 2016-Integer.parseInt(fechaNacimiento.substring(4));
		String direccion = getRandomDireccion();
		String email = creaEmail(nombre,apellido1,apellido2);
		String telefono = getRandomTelefono();
		String derechos = getRandomDerechos();
		
		
		res += "crear_usuario ('"+ nombre +"', '"+ apellido1 +" "+ apellido2 
				+"', to_date('"+ fechaNacimiento + "', 'ddmmYYYY'), '"+ direccion 
				+"', '"+ email +"', "+ telefono +", "+ derechos + ");";
		
		if (edad<18){
			res += "\n"+creaResponsable(apellido1, telefono);
			res += "\ncrear_relacion(sec_u.currval, sec_r.currval, 'Padre');";
		};
		
		Integer aniosVeterania = getAniosVeterania(edad);
		Integer anioMatriculacion = 2015;
		Integer[] instrumentos={randBetween(1, 11),randBetween(1, 11)};
		for (int i=0; i<aniosVeterania; i++){
			Boolean infantil = false;
			if (edad<7){
				infantil = true;
			}
			res += "\n"+crearMatricula(anioMatriculacion,aniosVeterania, infantil, edad, instrumentos);
			anioMatriculacion --;
			edad++;
		}
		
		
				
		return res;
	}

	private static String crearMatricula(Integer anioMatriculacion, Integer aniosVeterania, Boolean menor, Integer edad, Integer[] instrumentos) {
		String res = "";
		String fechaMatriculacion = getFechaMatriculacion(anioMatriculacion);
		Integer curso = anioMatriculacion-(2015-aniosVeterania);
		String codigo = getCodigo(anioMatriculacion,curso, menor);
		res += "crear_matricula(to_date('"+ fechaMatriculacion + "', 'ddmmYYYY'), "+curso+", '"+codigo+"', sec_u.currval);";
		res += "\ncrear_pertenece_a(sec_m.currval,oid_a12);";
		res += "\ncrear_pertenece_a(sec_m.currval,oid_a14);";
		Integer instrumento1 = null, instrumento2 = null;
		if (edad<7){
			res += "\ncrear_pertenece_a(sec_m.currval,oid_a1);";
			res += "\ncrear_pertenece_a(sec_m.currval,oid_a13);";
			instrumento1 = 1;
		} else {
			res += "\ncrear_pertenece_a(sec_m.currval,oid_a"+instrumentos[0]+");";
			res += "\ncrear_pertenece_a(sec_m.currval,oid_a"+instrumentos[1]+");";
			instrumento1 = instrumentos[0];
			instrumento2 = instrumentos[1];
		}
		if (instrumento1!=null) {
			res += crearPrestamo(instrumento1, fechaMatriculacion, anioMatriculacion);
		}
		if (instrumento2!=null){
			res += crearPrestamo(instrumento2, fechaMatriculacion, anioMatriculacion);
		}
		
		
		return res;
	}
	
	private static String crearPrestamo(Integer instrumento, String fechaMatriculacion, Integer anioMatriculacion) {
		String res = "";
		String strInstrumento = "";
		switch (instrumento) {
		case 1:
			strInstrumento = "violin";
			break;
		case 6:
			strInstrumento = "clarinete";
			break;
		case 8:
			strInstrumento = "trompeta";
			break;
		case 11:
			strInstrumento = "guitarra";
			break;
		}

		for (String inst : instrumentos.keySet()){
			if (inst.startsWith(strInstrumento) && instrumentos.get(inst)){
				res += "\ncrear_prestamo(to_date('"+ fechaMatriculacion + "', 'ddmmYYYY'),sec_m.currval,oid_"+inst+");";
				if (anioMatriculacion != 2015)
					res +=  "\nUPDATE instrumentos SET libre=1 WHERE oid_i=oid_"+inst+";";
				else
					instrumentos.put(inst, false);
				break;
			}
		}
		
		return res;
	}
	
	private static String getCodigo(Integer anioMatriculacion, Integer curso, Boolean menor) {
		String res = "";
		if (menor) res += "i";
		res += curso;
		matriculas[2015-anioMatriculacion][curso-1]++;
		String n ="" + matriculas[2015-anioMatriculacion][curso-1];
		if (n.length()<2) n = "0"+n;
		return res + n;
	}
	private static String getFechaMatriculacion(Integer anioMatriculacion) {
		String dia = String.valueOf(randBetween(1, 15));
		if (dia.length()<2) dia = "0" + dia;
		return dia+"09"+anioMatriculacion;
	}
	
	private static Integer getAniosVeterania(Integer edad) {
		Integer res;
		if (edad<6){
			res = randBetween(1, edad-3);
		} else{
			res = randBetween(1, 4);
		}
		return res;
	}
	private static String creaResponsable(String apellido1, String telefono) {
		String nombre = Nombres.getRandomNombre();
		String apellido2 = Apellidos.getRandomApellido();
		String email = creaEmail(nombre,apellido1,apellido2);
		return "crear_responsable('"+ nombre +"', '"+ apellido1 +" "+ apellido2 +"', '"+email+"', "+telefono+");";
	}

	private static String creaEmail(String nombre, String apellido1, String apellido2) {
		String res = "";
		if (nombre.length()<3){
			res += nombre.substring(0, 2);
		} else {
			res += nombre.substring(0, 3);
		}
		if (nombre.length()<3){
			res += apellido1.substring(0, 2);
		} else {
			res += apellido1.substring(0, 3);
		}
		if (nombre.length()<3){
			res += apellido2.substring(0, 2);
		} else {
			res += apellido2.substring(0, 3);
		}
		res = res.replace(" ", "").replace("�", "a").replace("�", "e")
				.replace("�", "i").replace("�", "o").replace("�", "u")
				.toLowerCase();
		
		return res + "@testmail.com";
	}

	private static String getRandomDerechos() {
		return ""+randBetween(0, 1);
	}

	private static String getRandomTelefono() {
		String res = "555";
			for (int i=0; i<6; i++)
				res += randBetween(0, 9);
		return res;
	}

	private static String getRandomDireccion() {
		Integer n = randBetween(1,10);
		Integer n2 = randBetween(1,50);
		return "Calle Test"+n+" n�"+n2;
	}

	private static String getRandomFechaNacimiento() {
		GregorianCalendar gc = new GregorianCalendar();
		int year = randBetween(1992, 2012);
		gc.set(GregorianCalendar.YEAR, year);
		int dayOfYear = randBetween(1, gc.getActualMaximum(GregorianCalendar.DAY_OF_YEAR));
		gc.set(GregorianCalendar.DAY_OF_YEAR, dayOfYear);
		
		String dia = String.valueOf(gc.get(GregorianCalendar.DAY_OF_MONTH));
		if (dia.length()<2) dia = "0" + dia;
		String mes = String.valueOf(gc.get(GregorianCalendar.MONTH) + 1);
		if (mes.length()<2) mes = "0" + mes;
				
		return dia + mes + gc.get(GregorianCalendar.YEAR);
	}
	
	private static int randBetween(int start, int end) {
        return start + (int)Math.round(Math.random() * (end - start));
    }
	
}
