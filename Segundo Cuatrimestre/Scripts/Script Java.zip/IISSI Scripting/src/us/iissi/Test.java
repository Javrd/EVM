package us.iissi;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Test {
	//TODO FALTAS Y PAGOS
	public static void main(String[] args) {
		String output = Factory.getRandomCargaInicial();
		PrintWriter out;
		try {
			out = new PrintWriter("Carga Inicial.sql");
			out.print(output);
			out.flush();
//			System.out.println(output);
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
}
